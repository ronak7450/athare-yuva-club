<?php
require_once 'auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Return success if logged in
echo json_encode(['success' => true]);
?>
